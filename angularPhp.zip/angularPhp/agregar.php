<?php
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: Origins, X-Requested-With, Content-Type, Accept");

    $json = file_get_contents('php://input');

    $params = json_decode($json);

    require("conexion.php");
    $con=retornaConexion();

    mysqli_query($con,"INSERT INTO clib_libros(cLIB_Nombre,cLIB_Estatus,cALU_IdAlumno) 
    VALUES ('$params->cLIB_Nombre', $params->cLIB_Estatus, '$params->cALU_IdAlumno')");

    class Result{}

    $response = new Result();
    $response->resultado = 'OK';
    $response->mensaje = 'Datos almacenados correctamente';
    
    header('Content-Type: application/json'); 
    echo json_encode($response);
?>