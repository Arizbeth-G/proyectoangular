<?php
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: Origins, X-Requested-With, Content-Type, Accept");

    require("conexion.php");
    $con=retornaConexion();

    $registros=mysqli_query($con,"SELECT * FROM clib_libros WHERE cLIB_IdLibro=$_GET[cLIB_IdLibro]");

    if($reg=mysqli_fetch_array($registros))
    {
        $vec[]=$reg;
    }

    $cad=json_encode($vec);
    echo $cad;
    header('Content-Type: application/json');     
?>