<?php
function retornaConexion(){
    $con=mysqli_connect("localhost","root","","libreria");
    return $con;
}
?>