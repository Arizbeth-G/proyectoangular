<?php
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: Origins, X-Requested-With, Content-Type, Accept");

    $json = file_get_contents('php://input');

    $params = json_decode($json);

    require("conexion.php");
    $con=retornaConexion();

    mysqli_query($con,"UPDATE cLIB_Libros SET cLIB_Nombre='$params->cLIB_Nombre',
                                            cLIB_Estatus=$params->cLIB_Estatus,
                                            cALU_IdAlumno='$params->cALU_IdAlumno'
                                            where cLIB_IdLibro = $params->cLIB_IdLibro");

    class Result{}

    $response = new Result();
    $response->resultado = 'OK';
    $response->mensaje = 'Datos actualizados correctamente';
    
    header('Content-Type: application/json'); 
    echo json_encode($response);
?>