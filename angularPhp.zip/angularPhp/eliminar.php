<?php
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: Origins, X-Requested-With, Content-Type, Accept");

    require("conexion.php");
    $con=retornaConexion();

    mysqli_query($con,"Delete from cLIB_Libros where cLIB_IdLibro=$_GET[cLIB_IdLibro]");

    class Result{}

    $response = new Result();
    $response->resultado = 'OK';
    $response->mensaje = 'Registro eliminado correctamente';
    
    header('Content-Type: application/json'); 
    echo json_encode($response);
?>