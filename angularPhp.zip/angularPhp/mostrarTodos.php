<?php
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: Origins, X-Requested-With, Content-Type, Accept");

    require("conexion.php");
    $con=retornaConexion();

    $registros=mysqli_query($con,"SELECT cLIB_IdLibro,cLIB_Nombre,cLIB_Estatus,cALU_IdAlumno FROM clib_libros");
    $vec=[];
    while($reg=mysqli_fetch_array($registros))
    {
        $vec[]=$reg;
    }

    $cad=json_encode($vec);
    echo $cad;
    header('Content-Type: application/json'); 
?>